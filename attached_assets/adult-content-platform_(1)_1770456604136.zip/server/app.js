import express from 'express';
const app = express();
app.listen(4000);
