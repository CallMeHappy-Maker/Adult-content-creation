
document.getElementById('adultForm').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Your adult content request has been submitted.');
});
