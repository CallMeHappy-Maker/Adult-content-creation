
function acceptAge() {
  document.getElementById('age-gate').style.display = 'none';
  document.getElementById('main-content').classList.remove('hidden');
}
